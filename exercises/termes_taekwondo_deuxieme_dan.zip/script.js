'use strict';

const CONFIG = {
  exerciseId: 'termes_taekwondo_deuxieme_dan',
  totalQuestions: 10,
  delayNextMs: 1400,
  passingRate: 0.6
};

const QUESTIONS = [
  {
    question: 'Que signifie le terme coréen « charyeot » ?',
    choices: ['Se mettre au garde-à-vous', 'Tourner à gauche', 'Donner un coup de pied', 'Respirer calmement', 'Saluer le partenaire'],
    correctAnswer: 'Se mettre au garde-à-vous'
  },
  {
    question: 'Que veut dire « kyongnye » en taekwondo ?',
    choices: ['Bloquer haut', 'Saluer', 'Frapper du poing', 'Changer de position', 'Compter les points'],
    correctAnswer: 'Saluer'
  },
  {
    question: 'Le terme « jirugi » désigne surtout :',
    choices: ['Un coup de poing', 'Un coup de pied circulaire', 'Une esquive', 'Une chute', 'Une respiration'],
    correctAnswer: 'Un coup de poing'
  },
  {
    question: 'Que signifie « makki » ?',
    choices: ['Blocage', 'Projection', 'Saut', 'Cri', 'Tour complet'],
    correctAnswer: 'Blocage'
  },
  {
    question: 'Le mot « ap » signifie généralement :',
    choices: ['Arrière', 'Avant', 'Droite', 'Gauche', 'Bas'],
    correctAnswer: 'Avant'
  },
  {
    question: 'Que désigne « dwit » ?',
    choices: ['Le côté', 'Le centre', 'Le saut', 'L’arrière', 'Le poing'],
    correctAnswer: 'L’arrière'
  },
  {
    question: '« Dollyo tchagui » est :',
    choices: ['Un coup de pied circulaire', 'Un blocage bas', 'Un salut officiel', 'Une position assise', 'Un coup de poing direct'],
    correctAnswer: 'Un coup de pied circulaire'
  },
  {
    question: 'Que signifie « yop tchagui » ?',
    choices: ['Coup de pied retourné', 'Coup de pied sauté', 'Coup de pied de face', 'Coup de pied latéral', 'Coup de genou'],
    correctAnswer: 'Coup de pied latéral'
  },
  {
    question: 'Le mot « poomsae » correspond à :',
    choices: ['Un combat libre', 'Une suite technique codifiée', 'Un échauffement rapide', 'Un type de protection', 'Une note d’examen'],
    correctAnswer: 'Une suite technique codifiée'
  },
  {
    question: 'Que veut dire « kihap » ?',
    choices: ['Saut tournant', 'Cri d’énergie', 'Retour au calme', 'Coup de coude', 'Arbitre central'],
    correctAnswer: 'Cri d’énergie'
  }
];

const state = {
  currentIndex: 0,
  score: 0,
  startTime: 0,
  isLocked: false,
  answers: []
};

const dom = {
  progressFill: document.getElementById('progress-fill'),
  progressLabel: document.getElementById('progress-label'),
  questionSection: document.getElementById('question-section'),
  questionText: document.getElementById('question-text'),
  answerSection: document.getElementById('answer-section'),
  btnValidate: document.getElementById('btn-validate'),
  feedback: document.getElementById('feedback'),
  resultScreen: document.getElementById('result-screen'),
  resultEmoji: document.getElementById('result-emoji'),
  resultTitle: document.getElementById('result-title'),
  resultScore: document.getElementById('result-score'),
  resultDetail: document.getElementById('result-detail'),
  btnRestart: document.getElementById('btn-restart')
};

function init() {
  state.currentIndex = 0;
  state.score = 0;
  state.startTime = Date.now();
  state.isLocked = false;
  state.answers = [];

  dom.questionSection.style.display = '';
  dom.resultScreen.classList.remove('is-visible');
  _clearFeedback();
  showQuestion();
}

function showQuestion() {
  state.isLocked = false;

  const questionData = QUESTIONS[state.currentIndex];
  const progressPercent = ((state.currentIndex + 1) / CONFIG.totalQuestions) * 100;

  dom.progressFill.style.width = progressPercent + '%';
  dom.progressLabel.textContent = (state.currentIndex + 1) + ' / ' + CONFIG.totalQuestions;
  dom.questionText.textContent = questionData.question;
  dom.btnValidate.classList.add('hidden');
  _clearFeedback();
  _renderChoices(questionData.choices);
}

function _renderChoices(choices) {
  dom.answerSection.innerHTML = '';

  const grid = document.createElement('div');
  grid.className = 'choices-grid';

  choices.forEach(function(choice) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'choice-btn';
    button.textContent = choice;
    button.addEventListener('click', function() {
      handleAnswer(choice);
    });
    grid.appendChild(button);
  });

  dom.answerSection.appendChild(grid);
}

function handleAnswer(value) {
  if (state.isLocked) {
    return;
  }

  state.isLocked = true;

  const questionData = QUESTIONS[state.currentIndex];
  const correct = questionData.correctAnswer;
  const isCorrect = value === correct;

  if (isCorrect) {
    state.score += 1;
    _setFeedback('Bravo ! Bonne réponse.', true);
  } else {
    _setFeedback('Ce n’est pas la bonne réponse. La bonne réponse est : ' + correct, false);
  }

  state.answers.push({
    question: questionData.question,
    given: String(value),
    correct: String(correct),
    ok: isCorrect
  });

  _markChoiceButton(value, correct);
  _disableAnswerSection();

  window.setTimeout(function() {
    state.currentIndex += 1;

    if (state.currentIndex >= CONFIG.totalQuestions) {
      showResult();
    } else {
      showQuestion();
    }
  }, CONFIG.delayNextMs);
}

function showResult() {
  const durationMs = Date.now() - state.startTime;
  const successRate = state.score / CONFIG.totalQuestions;
  const percentage = Math.round(successRate * 100);
  const hasPassed = successRate >= CONFIG.passingRate;

  dom.questionSection.style.display = 'none';
  dom.resultScreen.classList.add('is-visible');
  dom.resultEmoji.textContent = hasPassed ? '🎉' : '💪';
  dom.resultTitle.textContent = hasPassed ? 'Bravo, tu progresses bien !' : 'Continue, tu vas y arriver !';
  dom.resultScore.textContent = state.score + ' / ' + CONFIG.totalQuestions;
  dom.resultDetail.textContent = percentage + '% de réussite • ' + _formatDuration(durationMs);

  const payload = {
    type: 'exercise_result',
    exerciseId: CONFIG.exerciseId,
    score: state.score,
    total: CONFIG.totalQuestions,
    successRate: successRate,
    durationMs: durationMs,
    answers: state.answers.map(function(answer) {
      return {
        question: answer.question,
        given: answer.given,
        correct: answer.correct,
        ok: answer.ok
      };
    })
  };

  _sendToFlutter(payload);
}

function _sendToFlutter(payload) {
  if (typeof ExerciseChannel !== 'undefined') {
    ExerciseChannel.postMessage(JSON.stringify(payload));
  } else {
    console.info('[ExerciseChannel] Hors Flutter :', payload);
  }
}

function _setFeedback(message, isCorrect) {
  dom.feedback.textContent = message;
  dom.feedback.className = 'feedback ' + (isCorrect ? 'feedback--correct' : 'feedback--wrong');
}

function _clearFeedback() {
  dom.feedback.textContent = '\u00A0';
  dom.feedback.className = 'feedback feedback--empty';
}

function _markChoiceButton(selectedValue, correctValue) {
  const buttons = dom.answerSection.querySelectorAll('.choice-btn');

  buttons.forEach(function(button) {
    const value = button.textContent;
    if (value === correctValue) {
      button.classList.add('choice-btn--correct');
    }
    if (value === selectedValue && value !== correctValue) {
      button.classList.add('choice-btn--wrong');
    }
  });
}

function _disableAnswerSection() {
  const interactiveElements = dom.answerSection.querySelectorAll('button, input');
  interactiveElements.forEach(function(element) {
    element.disabled = true;
  });
}

function _formatDuration(durationMs) {
  const totalSeconds = Math.max(1, Math.round(durationMs / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  if (minutes > 0) {
    return minutes + ' min ' + String(seconds).padStart(2, '0') + ' s';
  }

  return seconds + ' s';
}

document.addEventListener('DOMContentLoaded', function() {
  dom.btnRestart.addEventListener('click', init);
  init();
});