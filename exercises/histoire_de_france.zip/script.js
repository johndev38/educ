'use strict';

const CONFIG = {
  exerciseId: 'histoire_de_france',
  totalQuestions: 8,
  delayNextMs: 1400,
  passingRate: 0.6
};

const QUESTIONS = [
  {
    question: 'Qui était le roi de France associé au château de Versailles ?',
    choices: ['Louis XIV', 'Napoléon Bonaparte', 'Charlemagne', 'François Ier'],
    correctAnswer: 'Louis XIV'
  },
  {
    question: 'Quel monument célèbre se trouve à Paris ?',
    choices: ['La tour Eiffel', 'Le Colisée', 'Big Ben', 'La statue de la Liberté'],
    correctAnswer: 'La tour Eiffel'
  },
  {
    question: 'Comment s\'appelait la jeune héroïne qui a aidé le roi pendant la guerre de Cent Ans ?',
    choices: ['Jeanne d\'Arc', 'Marie Curie', 'Joséphine', 'Aliénor'],
    correctAnswer: 'Jeanne d\'Arc'
  },
  {
    question: 'En 1789, quel grand événement commence en France ?',
    choices: ['La Révolution française', 'La construction de la tour Eiffel', 'La Première Guerre mondiale', 'Le sacre de Napoléon'],
    correctAnswer: 'La Révolution française'
  },
  {
    question: 'Quel chef français est devenu empereur en 1804 ?',
    choices: ['Napoléon Bonaparte', 'Louis XVI', 'Clovis', 'Victor Hugo'],
    correctAnswer: 'Napoléon Bonaparte'
  },
  {
    question: 'Quel roi est souvent présenté comme le premier roi des Francs ?',
    choices: ['Clovis', 'Henri IV', 'Louis XV', 'Charles de Gaulle'],
    correctAnswer: 'Clovis'
  },
  {
    question: 'Quel symbole bleu-blanc-rouge représente la France ?',
    choices: ['Le drapeau français', 'Un bouclier romain', 'Une couronne dorée', 'Une épée royale'],
    correctAnswer: 'Le drapeau français'
  },
  {
    question: 'Qui était le général devenu président important après la Seconde Guerre mondiale ?',
    choices: ['Charles de Gaulle', 'Louis XIV', 'Molière', 'Gustave Eiffel'],
    correctAnswer: 'Charles de Gaulle'
  }
];

const state = {
  currentIndex: 0,
  score: 0,
  startTime: 0,
  isLocked: false,
  answers: []
};

const dom = {
  progressFill: document.getElementById('progress-fill'),
  progressLabel: document.getElementById('progress-label'),
  questionSection: document.getElementById('question-section'),
  questionText: document.getElementById('question-text'),
  answerSection: document.getElementById('answer-section'),
  btnValidate: document.getElementById('btn-validate'),
  feedback: document.getElementById('feedback'),
  resultScreen: document.getElementById('result-screen'),
  resultEmoji: document.getElementById('result-emoji'),
  resultTitle: document.getElementById('result-title'),
  resultScore: document.getElementById('result-score'),
  resultDetail: document.getElementById('result-detail'),
  btnRestart: document.getElementById('btn-restart')
};

function init() {
  state.currentIndex = 0;
  state.score = 0;
  state.startTime = Date.now();
  state.isLocked = false;
  state.answers = [];

  dom.questionSection.style.display = 'block';
  dom.resultScreen.classList.remove('is-visible');
  _clearFeedback();
  showQuestion();
}

function showQuestion() {
  const questionActuelle = QUESTIONS[state.currentIndex];
  const progression = ((state.currentIndex + 1) / CONFIG.totalQuestions) * 100;

  dom.progressFill.style.width = progression + '%';
  dom.progressLabel.textContent = (state.currentIndex + 1) + ' / ' + CONFIG.totalQuestions;
  dom.questionText.textContent = questionActuelle.question;
  dom.btnValidate.style.display = 'none';
  dom.answerSection.innerHTML = '';
  _clearFeedback();
  _renderChoices(questionActuelle);
}

function _renderChoices(questionObj) {
  const grille = document.createElement('div');
  grille.className = 'choices-grid';

  questionObj.choices.forEach(function(choix) {
    const bouton = document.createElement('button');
    bouton.className = 'choice-btn';
    bouton.type = 'button';
    bouton.textContent = choix;
    bouton.addEventListener('click', function() {
      handleAnswer(choix);
    });
    grille.appendChild(bouton);
  });

  dom.answerSection.appendChild(grille);
}

function _renderTextInput() {
}

function handleAnswer(value) {
  if (state.isLocked) {
    return;
  }

  state.isLocked = true;

  const questionActuelle = QUESTIONS[state.currentIndex];
  const estCorrect = value === questionActuelle.correctAnswer;

  if (estCorrect) {
    state.score += 1;
    _setFeedback('Bravo, c\'est la bonne réponse !', true);
  } else {
    _setFeedback('Ce n\'est pas tout à fait ça. La bonne réponse est : ' + questionActuelle.correctAnswer, false);
  }

  state.answers.push({
    question: questionActuelle.question,
    given: String(value),
    correct: questionActuelle.correctAnswer,
    ok: estCorrect
  });

  _markChoiceButton(value, questionActuelle.correctAnswer);
  _disableAnswerSection();

  window.setTimeout(function() {
    state.currentIndex += 1;
    state.isLocked = false;

    if (state.currentIndex >= CONFIG.totalQuestions) {
      showResult();
    } else {
      showQuestion();
    }
  }, CONFIG.delayNextMs);
}

function showResult() {
  const dureeMs = Date.now() - state.startTime;
  const taux = state.score / CONFIG.totalQuestions;
  const pourcentage = Math.round(taux * 100);
  const reussi = taux >= CONFIG.passingRate;

  dom.questionSection.style.display = 'none';
  dom.resultScreen.classList.add('is-visible');
  dom.resultEmoji.textContent = reussi ? '🎉' : '💪';
  dom.resultTitle.textContent = reussi ? 'Bravo, tu connais bien l\'histoire de France !' : 'Continue, tu progresses très bien !';
  dom.resultScore.textContent = state.score + ' / ' + CONFIG.totalQuestions;
  dom.resultDetail.textContent = pourcentage + '% de réussite · ' + _formatDuration(dureeMs);

  const payload = {
    type: 'exercise_result',
    exerciseId: CONFIG.exerciseId,
    score: state.score,
    total: CONFIG.totalQuestions,
    successRate: taux,
    durationMs: dureeMs,
    answers: state.answers.map(function(answer) {
      return {
        question: answer.question,
        given: answer.given,
        correct: answer.correct,
        ok: answer.ok
      };
    })
  };

  _sendToFlutter(payload);
}

function _sendToFlutter(payload) {
  if (typeof ExerciseChannel !== 'undefined') {
    ExerciseChannel.postMessage(JSON.stringify(payload));
  } else {
    console.info('[ExerciseChannel] Hors Flutter :', payload);
  }
}

function _setFeedback(message, estCorrect) {
  dom.feedback.textContent = message;
  dom.feedback.className = 'feedback ' + (estCorrect ? 'feedback--correct' : 'feedback--wrong');
}

function _clearFeedback() {
  dom.feedback.textContent = ' ';
  dom.feedback.className = 'feedback feedback--empty';
}

function _markChoiceButton(reponseDonnee, bonneReponse) {
  const boutons = dom.answerSection.querySelectorAll('.choice-btn');

  boutons.forEach(function(bouton) {
    if (bouton.textContent === bonneReponse) {
      bouton.classList.add('choice-btn--correct');
    }
    if (bouton.textContent === reponseDonnee && reponseDonnee !== bonneReponse) {
      bouton.classList.add('choice-btn--wrong');
    }
  });
}

function _disableAnswerSection() {
  const elements = dom.answerSection.querySelectorAll('button, input');
  elements.forEach(function(element) {
    element.disabled = true;
  });
}

function _formatDuration(durationMs) {
  const totalSecondes = Math.max(1, Math.round(durationMs / 1000));
  const minutes = Math.floor(totalSecondes / 60);
  const secondes = totalSecondes % 60;

  if (minutes === 0) {
    return secondes + ' s';
  }

  return minutes + ' min ' + secondes + ' s';
}

dom.btnRestart.addEventListener('click', init);

document.addEventListener('DOMContentLoaded', init);
