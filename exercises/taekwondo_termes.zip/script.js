'use strict';

const CONFIG = {
  exerciseId: 'taekwondo_termes',
  streakTarget: 12,
  timerMs: 8000,
  tickMs: 100,
  delayAfterCorrect: 700,
  delayAfterWrong: 1500,
  maxQuestions: 80,
};

const DATA = {
  1: [
    { family: 'Consignes', ko: 'Tchaliot', fr: 'Garde à vous' },
    { family: 'Consignes', ko: 'Kyongnye', fr: 'Saluez' },
    { family: 'Consignes', ko: 'Tchoumbi', fr: 'Position de départ' },
    { family: 'Consignes', ko: 'Shijak', fr: 'Commencez' },
    { family: 'Consignes', ko: 'Keuman', fr: 'Arrêtez' },
    { family: 'Consignes', ko: 'Chwio', fr: 'Repos' },
    { family: 'Consignes', ko: 'Baro', fr: 'Revenez' },
    { family: 'Consignes', ko: 'Dwiro Dora', fr: 'Demi-tour' },
    { family: 'Corps', ko: 'Joumok', fr: 'Poing' },
    { family: 'Corps', ko: 'Bal', fr: 'Pied' },
    { family: 'Corps', ko: 'Sonnal', fr: 'Tranchant de la main' },
    { family: 'Corps', ko: 'Batangsonn', fr: 'Paume' },
    { family: 'Corps', ko: 'Palkoup', fr: 'Coude' },
    { family: 'Corps', ko: 'Moureup', fr: 'Genou' },
    { family: 'Directions', ko: 'Wen tchouk', fr: 'À gauche' },
    { family: 'Directions', ko: 'Orun tchouk', fr: 'À droite' },
    { family: 'Chiffres', ko: 'Hana', fr: 'Un' },
    { family: 'Chiffres', ko: 'Doul', fr: 'Deux' },
    { family: 'Chiffres', ko: 'Set', fr: 'Trois' },
    { family: 'Chiffres', ko: 'Net', fr: 'Quatre' },
    { family: 'Chiffres', ko: 'Dasot', fr: 'Cinq' },
    { family: 'Culture', ko: 'Dobok', fr: 'Tenue de taekwondo' },
    { family: 'Culture', ko: 'Ti', fr: 'Ceinture' },
    { family: 'Culture', ko: 'Dojang', fr: 'Salle d’entraînement' },
    { family: 'Culture', ko: 'Kihap', fr: 'Cri' },
    { family: 'Culture', ko: 'Kyorugui', fr: 'Combat' },
    { family: 'Culture', ko: 'Poumse', fr: 'Forme' },
  ],
  2: [
    { family: 'Positions', ko: 'Ap seugui', fr: 'Position avant' },
    { family: 'Positions', ko: 'Ap koubi', fr: 'Position longue avant' },
    { family: 'Positions', ko: 'Dwit koubi', fr: 'Position arrière' },
    { family: 'Positions', ko: 'Juchum seugui', fr: 'Position cavalier' },
    { family: 'Blocages', ko: 'Arae makki', fr: 'Blocage bas' },
    { family: 'Blocages', ko: 'Momtong makki', fr: 'Blocage au tronc' },
    { family: 'Blocages', ko: 'Eolgoul makki', fr: 'Blocage haut' },
    { family: 'Blocages', ko: 'Bakkat makki', fr: 'Blocage extérieur' },
    { family: 'Attaques', ko: 'Montong jireugi', fr: 'Coup de poing au tronc' },
    { family: 'Attaques', ko: 'Eolgoul jireugi', fr: 'Coup de poing au visage' },
    { family: 'Attaques', ko: 'Deung joumok ap tchigui', fr: 'Revers du poing vers l’avant' },
    { family: 'Attaques', ko: 'Me joumok naeryo tchigui', fr: 'Marteau descendant' },
    { family: 'Niveaux', ko: 'Arae', fr: 'Niveau bas' },
    { family: 'Niveaux', ko: 'Momtong', fr: 'Niveau moyen' },
    { family: 'Niveaux', ko: 'Eolgoul', fr: 'Niveau haut' },
    { family: 'Déplacements', ko: 'Apeuro Nagamienso', fr: 'En avançant' },
    { family: 'Déplacements', ko: 'Dwiro Moulo namien so', fr: 'En reculant' },
    { family: 'Déplacements', ko: 'Jésari', fr: 'Sur place' },
  ],
  3: [
    { family: 'Coups de pied', ko: 'Ap tchagui', fr: 'Coup de pied avant' },
    { family: 'Coups de pied', ko: 'Dollyo tchagui', fr: 'Coup de pied circulaire' },
    { family: 'Coups de pied', ko: 'Yop tchagui', fr: 'Coup de pied latéral' },
    { family: 'Coups de pied', ko: 'Dwit tchagui', fr: 'Coup de pied arrière' },
    { family: 'Coups de pied', ko: 'Naeryo tchagui', fr: 'Coup de pied marteau descendant' },
    { family: 'Coups de pied', ko: 'Bandal tchagui', fr: 'Coup de pied semi-circulaire' },
    { family: 'Directions', ko: 'Ap', fr: 'De face' },
    { family: 'Directions', ko: 'Dwit', fr: 'Derrière' },
    { family: 'Directions', ko: 'Yop', fr: 'De côté' },
    { family: 'Poomsae', ko: 'Taegeuk Il Jang', fr: '1er poomsae Taegeuk' },
    { family: 'Poomsae', ko: 'Taegeuk Yi Jang', fr: '2e poomsae Taegeuk' },
    { family: 'Poomsae', ko: 'Taegeuk Sam Jang', fr: '3e poomsae Taegeuk' },
    { family: 'Poomsae', ko: 'Taegeuk Sa Jang', fr: '4e poomsae Taegeuk' },
    { family: 'Poomsae', ko: 'Taegeuk Oh Jang', fr: '5e poomsae Taegeuk' },
    { family: 'Poomsae', ko: 'Taegeuk Yuk Jang', fr: '6e poomsae Taegeuk' },
    { family: 'Poomsae', ko: 'Taegeuk Chil Jang', fr: '7e poomsae Taegeuk' },
    { family: 'Poomsae', ko: 'Taegeuk Pal Jang', fr: '8e poomsae Taegeuk' },
    { family: 'Poomsae', ko: 'Keumgang', fr: 'Poomsae supérieur du diamant / de la montagne' },
    { family: 'Grades', ko: 'Keup', fr: 'Niveau avant la ceinture noire' },
    { family: 'Grades', ko: 'Dan', fr: 'Niveau à partir de la ceinture noire' },
  ],
};

const state = {
  level: null,
  streak: 0,
  bestStreak: 0,
  correctTotal: 0,
  questionsTotal: 0,
  answers: [],
  currentQuestion: null,
  timerRemaining: 0,
  timerInterval: null,
  isLocked: false,
  hasWon: false,
  startTime: 0,
};

const dom = {
  startScreen: document.getElementById('start-screen'),
  gameScreen: document.getElementById('game-screen'),
  resultScreen: document.getElementById('result-screen'),
  levelButtons: Array.from(document.querySelectorAll('.level-btn')),
  streakValue: document.getElementById('streak-value'),
  bestStreak: document.getElementById('best-streak'),
  levelLabel: document.getElementById('level-label'),
  questionCount: document.getElementById('question-count'),
  modeLabel: document.getElementById('mode-label'),
  familyLabel: document.getElementById('family-label'),
  questionText: document.getElementById('question-text'),
  answerSection: document.getElementById('answer-section'),
  feedback: document.getElementById('feedback'),
  timerBar: document.getElementById('timer-bar'),
  timerLabel: document.getElementById('timer-label'),
  streakDots: document.getElementById('streak-dots'),
  resultEmoji: document.getElementById('result-emoji'),
  resultTitle: document.getElementById('result-title'),
  resultSummary: document.getElementById('result-summary'),
  resultScore: document.getElementById('result-score'),
  btnRestart: document.getElementById('btn-restart'),
};

function init() {
  state.level = null;
  state.streak = 0;
  state.bestStreak = 0;
  state.correctTotal = 0;
  state.questionsTotal = 0;
  state.answers = [];
  state.currentQuestion = null;
  state.timerRemaining = 0;
  state.isLocked = false;
  state.hasWon = false;
  state.startTime = 0;
  stopTimer();

  dom.startScreen.classList.remove('hidden');
  dom.gameScreen.classList.add('hidden');
  dom.resultScreen.classList.add('hidden');
  updateCounters();
  buildStreakDots();
  clearFeedback();
}

function startGame(level) {
  state.level = Number(level);
  state.streak = 0;
  state.bestStreak = 0;
  state.correctTotal = 0;
  state.questionsTotal = 0;
  state.answers = [];
  state.currentQuestion = null;
  state.isLocked = false;
  state.hasWon = false;
  state.startTime = Date.now();

  dom.startScreen.classList.add('hidden');
  dom.resultScreen.classList.add('hidden');
  dom.gameScreen.classList.remove('hidden');
  dom.levelLabel.textContent = String(state.level);

  buildStreakDots();
  updateCounters();
  showQuestion();
}

function showQuestion() {
  if (state.questionsTotal >= CONFIG.maxQuestions) {
    endGame(false);
    return;
  }

  state.isLocked = false;
  clearFeedback();

  const entries = DATA[state.level];
  const entry = entries[randInt(0, entries.length - 1)];
  const askKoToFr = Math.random() < 0.7;
  const prompt = askKoToFr ? entry.ko : entry.fr;
  const correct = askKoToFr ? entry.fr : entry.ko;
  const mode = askKoToFr ? 'Coréen → Français' : 'Français → Coréen';

  const pool = entries
    .map(item => askKoToFr ? item.fr : item.ko)
    .filter(value => value !== correct);

  const choices = shuffle([correct, ...pickUnique(pool, 3)]);

  state.currentQuestion = {
    family: entry.family,
    mode,
    prompt,
    correct,
    choices,
  };

  dom.modeLabel.textContent = mode;
  dom.familyLabel.textContent = entry.family;
  dom.questionText.textContent = prompt;
  renderChoices(choices);
  updateCounters();
  startTimer();
}

function renderChoices(choices) {
  dom.answerSection.innerHTML = '';
  choices.forEach(choice => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'choice-btn';
    button.textContent = choice;
    button.addEventListener('click', () => handleAnswer(choice));
    dom.answerSection.appendChild(button);
  });
}

function handleAnswer(choice) {
  if (state.isLocked) return;
  state.isLocked = true;
  stopTimer();

  const question = state.currentQuestion;
  const ok = choice === question.correct;
  state.questionsTotal += 1;

  state.answers.push({
    prompt: question.prompt,
    correct: question.correct,
    given: choice,
    ok,
    level: state.level,
  });

  markButtons(choice, question.correct, ok);

  if (ok) {
    state.correctTotal += 1;
    state.streak += 1;
    state.bestStreak = Math.max(state.bestStreak, state.streak);
    setFeedback('correct', successMessage());
    updateCounters();
    updateStreakDots();

    if (state.streak >= CONFIG.streakTarget) {
      setTimeout(() => endGame(true), CONFIG.delayAfterCorrect);
    } else {
      setTimeout(showQuestion, CONFIG.delayAfterCorrect);
    }
    return;
  }

  const previousStreak = state.streak;
  state.streak = 0;
  updateCounters();
  updateStreakDots();
  setFeedback('wrong', previousStreak > 0
    ? `❌ La bonne réponse était : ${question.correct}. Série perdue.`
    : `❌ La bonne réponse était : ${question.correct}`);
  setTimeout(showQuestion, CONFIG.delayAfterWrong);
}

function onTimeout() {
  if (state.isLocked) return;
  state.isLocked = true;

  const question = state.currentQuestion;
  state.questionsTotal += 1;
  state.answers.push({
    prompt: question.prompt,
    correct: question.correct,
    given: '(temps écoulé)',
    ok: false,
    level: state.level,
  });

  markOnlyCorrect(question.correct);

  const previousStreak = state.streak;
  state.streak = 0;
  updateCounters();
  updateStreakDots();
  setFeedback('wrong', previousStreak > 0
    ? `⏰ Temps écoulé. La bonne réponse était : ${question.correct}. Série perdue.`
    : `⏰ Temps écoulé. La bonne réponse était : ${question.correct}`);

  setTimeout(showQuestion, CONFIG.delayAfterWrong);
}

function startTimer() {
  stopTimer();
  state.timerRemaining = CONFIG.timerMs;
  updateTimerDisplay();

  state.timerInterval = setInterval(() => {
    state.timerRemaining -= CONFIG.tickMs;
    updateTimerDisplay();
    if (state.timerRemaining <= 0) {
      stopTimer();
      onTimeout();
    }
  }, CONFIG.tickMs);
}

function stopTimer() {
  if (state.timerInterval !== null) {
    clearInterval(state.timerInterval);
    state.timerInterval = null;
  }
}

function updateTimerDisplay() {
  const pct = Math.max(0, (state.timerRemaining / CONFIG.timerMs) * 100);
  const seconds = Math.max(0, Math.ceil(state.timerRemaining / 1000));

  dom.timerBar.style.width = `${pct}%`;
  dom.timerLabel.textContent = String(seconds);

  if (pct > 50) {
    dom.timerBar.style.background = 'var(--success)';
  } else if (pct > 20) {
    dom.timerBar.style.background = 'var(--warning)';
  } else {
    dom.timerBar.style.background = 'var(--danger)';
  }
}

function updateCounters() {
  dom.streakValue.textContent = String(state.streak);
  dom.bestStreak.textContent = String(state.bestStreak);
  dom.questionCount.textContent = String(state.questionsTotal + 1);
}

function buildStreakDots() {
  dom.streakDots.innerHTML = '';
  for (let i = 0; i < CONFIG.streakTarget; i += 1) {
    const dot = document.createElement('div');
    dot.className = 'streak-dot';
    dom.streakDots.appendChild(dot);
  }
  updateStreakDots();
}

function updateStreakDots() {
  const dots = Array.from(dom.streakDots.children);
  dots.forEach((dot, index) => {
    dot.classList.toggle('active', index < state.streak);
  });
}

function markButtons(choice, correct, ok) {
  Array.from(dom.answerSection.querySelectorAll('.choice-btn')).forEach(btn => {
    btn.disabled = true;
    if (btn.textContent === correct) {
      btn.classList.add('choice-btn--correct');
    }
    if (!ok && btn.textContent === choice) {
      btn.classList.add('choice-btn--wrong');
    }
  });
}

function markOnlyCorrect(correct) {
  Array.from(dom.answerSection.querySelectorAll('.choice-btn')).forEach(btn => {
    btn.disabled = true;
    if (btn.textContent === correct) {
      btn.classList.add('choice-btn--correct');
    }
  });
}

function setFeedback(type, message) {
  dom.feedback.textContent = message;
  dom.feedback.className = `feedback feedback--${type}`;
}

function clearFeedback() {
  dom.feedback.textContent = '';
  dom.feedback.className = 'feedback feedback--empty';
}

function successMessage() {
  if (state.streak >= 10) return `🥋 ${state.streak} de suite, excellent !`;
  if (state.streak >= 5) return `💥 ${state.streak} de suite, continuez !`;
  const messages = ['✅ Exact !', '✅ Bravo !', '✅ Très bien !', '✅ Parfait !'];
  return messages[randInt(0, messages.length - 1)];
}

function endGame(won) {
  stopTimer();
  state.hasWon = won;

  const durationMs = Date.now() - state.startTime;
  const successRate = state.questionsTotal > 0 ? state.correctTotal / state.questionsTotal : 0;

  dom.gameScreen.classList.add('hidden');
  dom.resultScreen.classList.remove('hidden');

  dom.resultEmoji.textContent = won ? '🏆' : '🥋';
  dom.resultTitle.textContent = won
    ? '12 bonnes réponses de suite !'
    : 'Fin de la session';
  dom.resultSummary.textContent = won
    ? `Niveau ${state.level} réussi. Meilleure série : ${state.bestStreak}.`
    : `Meilleure série : ${state.bestStreak}. Continuez l'entraînement.`;
  dom.resultScore.textContent = `${state.correctTotal} / ${state.questionsTotal} · ${Math.round(successRate * 100)} % · ${Math.round(durationMs / 1000)} s`;

  sendToFlutter({
    type: 'exercise_result',
    exerciseId: CONFIG.exerciseId,
    level: state.level,
    score: state.correctTotal,
    total: state.questionsTotal,
    successRate,
    durationMs,
    answers: state.answers,
  });
}

function sendToFlutter(payload) {
  const json = JSON.stringify(payload);
  if (typeof ExerciseChannel !== 'undefined') {
    ExerciseChannel.postMessage(json);
  } else {
    console.info('[ExerciseChannel] Hors Flutter :', payload);
  }
}

function pickUnique(pool, count) {
  const copy = shuffle([...pool]);
  return copy.slice(0, Math.min(count, copy.length));
}

function shuffle(array) {
  for (let i = array.length - 1; i > 0; i -= 1) {
    const j = randInt(0, i);
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

dom.levelButtons.forEach(button => {
  button.addEventListener('click', () => startGame(button.dataset.level));
});

dom.btnRestart.addEventListener('click', init);

init();
