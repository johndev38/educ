'use strict';

const CONFIG = {
  exerciseId: 'les_fractions',
  totalQuestions: 8,
  delayNextMs: 1400,
  passingRate: 0.6
};

const QUESTIONS = [
  {
    question: 'Quelle fraction représente une moitié ?',
    choices: ['1/2', '1/3', '2/3', '1/4'],
    correct: '1/2'
  },
  {
    question: 'Quelle fraction représente un quart ?',
    choices: ['1/2', '1/4', '3/4', '2/4'],
    correct: '1/4'
  },
  {
    question: 'Dans la fraction 3/4, quel est le dénominateur ?',
    choices: ['3', '4', '7', '1'],
    correct: '4'
  },
  {
    question: 'Quelle fraction est plus grande que 1/2 ?',
    choices: ['1/4', '2/3', '1/3', '2/6'],
    correct: '2/3'
  },
  {
    question: 'Si une pizza est coupée en 4 parts et tu en manges 3, quelle fraction as-tu mangée ?',
    choices: ['1/4', '2/4', '3/4', '4/4'],
    correct: '3/4'
  },
  {
    question: 'Quelle fraction est équivalente à 2/4 ?',
    choices: ['1/2', '1/3', '3/4', '2/3'],
    correct: '1/2'
  },
  {
    question: 'Quelle fraction est la plus petite ?',
    choices: ['1/2', '1/5', '1/3', '1/4'],
    correct: '1/5'
  },
  {
    question: 'Si un gâteau est partagé en 8 parts et que 2 parts sont prises, quelle fraction reste ?',
    choices: ['2/8', '4/8', '6/8', '8/8'],
    correct: '6/8'
  }
];

const state = {
  currentIndex: 0,
  score: 0,
  startTime: 0,
  isLocked: false,
  answers: []
};

const dom = {
  progressFill: document.getElementById('progress-fill'),
  progressLabel: document.getElementById('progress-label'),
  questionSection: document.getElementById('question-section'),
  questionText: document.getElementById('question-text'),
  answerSection: document.getElementById('answer-section'),
  btnValidate: document.getElementById('btn-validate'),
  feedback: document.getElementById('feedback'),
  resultScreen: document.getElementById('result-screen'),
  resultEmoji: document.getElementById('result-emoji'),
  resultTitle: document.getElementById('result-title'),
  resultScore: document.getElementById('result-score'),
  resultDetail: document.getElementById('result-detail'),
  btnRestart: document.getElementById('btn-restart')
};

function init() {
  state.currentIndex = 0;
  state.score = 0;
  state.startTime = Date.now();
  state.isLocked = false;
  state.answers = [];

  dom.questionSection.style.display = 'block';
  dom.resultScreen.classList.remove('is-visible');
  _clearFeedback();
  showQuestion();
}

function showQuestion() {
  const questionCourante = QUESTIONS[state.currentIndex];
  const progression = ((state.currentIndex) / CONFIG.totalQuestions) * 100;

  dom.progressFill.style.width = progression + '%';
  dom.progressLabel.textContent = (state.currentIndex + 1) + ' / ' + CONFIG.totalQuestions;
  dom.questionText.textContent = questionCourante.question;
  dom.btnValidate.style.display = 'none';
  _clearFeedback();
  _renderChoices(questionCourante.choices);
  state.isLocked = false;
}

function _renderChoices(choix) {
  dom.answerSection.innerHTML = '';

  const grille = document.createElement('div');
  grille.className = 'choices-grid';

  choix.forEach(function (choixTexte) {
    const bouton = document.createElement('button');
    bouton.className = 'choice-btn';
    bouton.type = 'button';
    bouton.textContent = choixTexte;
    bouton.addEventListener('click', function () {
      handleAnswer(choixTexte, bouton);
    });
    grille.appendChild(bouton);
  });

  dom.answerSection.appendChild(grille);
}

function _renderTextInput() {
  dom.answerSection.innerHTML = '';
  const input = document.createElement('input');
  input.className = 'input-answer';
  input.type = 'text';
  input.placeholder = 'Écris ta réponse';
  dom.answerSection.appendChild(input);
  dom.btnValidate.style.display = 'block';
}

function handleAnswer(value, boutonClique) {
  if (state.isLocked) {
    return;
  }

  state.isLocked = true;

  const questionCourante = QUESTIONS[state.currentIndex];
  const estCorrect = value === questionCourante.correct;

  if (estCorrect) {
    state.score += 1;
    _setFeedback('Bravo, c\'est la bonne réponse !', true);
    if (boutonClique) {
      _markChoiceButton(boutonClique, true);
    }
  } else {
    _setFeedback('Oups ! La bonne réponse était ' + questionCourante.correct + '.', false);
    if (boutonClique) {
      _markChoiceButton(boutonClique, false);
    }
    _highlightCorrectChoice(questionCourante.correct);
  }

  state.answers.push({
    question: questionCourante.question,
    given: String(value),
    correct: String(questionCourante.correct),
    ok: estCorrect
  });

  _disableAnswerSection();

  window.setTimeout(function () {
    state.currentIndex += 1;

    if (state.currentIndex >= CONFIG.totalQuestions) {
      showResult();
    } else {
      showQuestion();
    }
  }, CONFIG.delayNextMs);
}

function showResult() {
  const duree = Date.now() - state.startTime;
  const taux = state.score / CONFIG.totalQuestions;
  const pourcentage = Math.round(taux * 100);
  const reussi = taux >= CONFIG.passingRate;

  dom.progressFill.style.width = '100%';
  dom.progressLabel.textContent = CONFIG.totalQuestions + ' / ' + CONFIG.totalQuestions;
  dom.questionSection.style.display = 'none';
  dom.resultScreen.classList.add('is-visible');
  dom.resultEmoji.textContent = reussi ? '🎉' : '💪';
  dom.resultTitle.textContent = reussi ? 'Bravo, tu réussis !' : 'Continue, tu progresses !';
  dom.resultScore.textContent = state.score + ' / ' + CONFIG.totalQuestions;
  dom.resultDetail.textContent = pourcentage + '% de réussite · ' + _formatDuration(duree);

  const payload = {
    type: 'exercise_result',
    exerciseId: CONFIG.exerciseId,
    score: state.score,
    total: CONFIG.totalQuestions,
    successRate: taux,
    durationMs: duree,
    answers: state.answers.map(function (reponse) {
      return {
        question: reponse.question,
        given: reponse.given,
        correct: reponse.correct,
        ok: reponse.ok
      };
    })
  };

  _sendToFlutter(payload);
}

function _sendToFlutter(payload) {
  if (typeof ExerciseChannel !== 'undefined') {
    ExerciseChannel.postMessage(JSON.stringify(payload));
  } else {
    console.info('[ExerciseChannel] Hors Flutter :', payload);
  }
}

function _setFeedback(message, estCorrect) {
  dom.feedback.textContent = message;
  dom.feedback.className = 'feedback ' + (estCorrect ? 'feedback--correct' : 'feedback--wrong');
}

function _clearFeedback() {
  dom.feedback.textContent = ' ';
  dom.feedback.className = 'feedback feedback--empty';
}

function _markChoiceButton(bouton, estCorrect) {
  bouton.classList.add(estCorrect ? 'choice-btn--correct' : 'choice-btn--wrong');
}

function _disableAnswerSection() {
  const boutons = dom.answerSection.querySelectorAll('button, input');
  boutons.forEach(function (element) {
    element.disabled = true;
  });
}

function _highlightCorrectChoice(bonneReponse) {
  const boutons = dom.answerSection.querySelectorAll('.choice-btn');
  boutons.forEach(function (bouton) {
    if (bouton.textContent === bonneReponse) {
      bouton.classList.add('choice-btn--correct');
    }
  });
}

function _formatDuration(ms) {
  const totalSecondes = Math.max(1, Math.round(ms / 1000));
  const minutes = Math.floor(totalSecondes / 60);
  const secondes = totalSecondes % 60;

  if (minutes <= 0) {
    return secondes + ' s';
  }

  return minutes + ' min ' + secondes + ' s';
}

dom.btnRestart.addEventListener('click', init);

document.addEventListener('DOMContentLoaded', init);