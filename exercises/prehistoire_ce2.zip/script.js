'use strict';

const CONFIG = {
  exerciseId: 'prehistoire_ce2',
  totalQuestions: 8,
  delayNextMs: 1400,
  passingRate: 0.6
};

const QUESTIONS = [
  {
    question: 'La Préhistoire, c\'est la période avant...?',
    choices: ['les voitures', 'l\'écriture', 'les châteaux', 'les ordinateurs'],
    correctAnswer: 'l\'écriture'
  },
  {
    question: 'Quel animal vivait à la Préhistoire ?',
    choices: ['Le mammouth', 'Le panda roux', 'Le dauphin rose', 'Le kangourou'],
    correctAnswer: 'Le mammouth'
  },
  {
    question: 'Avec quoi les hommes préhistoriques fabriquaient-ils souvent leurs outils ?',
    choices: ['Du plastique', 'De la pierre', 'Du carton', 'Du verre'],
    correctAnswer: 'De la pierre'
  },
  {
    question: 'Où trouve-t-on souvent des peintures préhistoriques ?',
    choices: ['Dans des grottes', 'Sur des bus', 'Dans des écoles', 'Sur des téléphones'],
    correctAnswer: 'Dans des grottes'
  },
  {
    question: 'Le feu servait surtout à...?',
    choices: ['regarder la télévision', 'cuire et se réchauffer', 'jouer aux cartes', 'éclairer les voitures'],
    correctAnswer: 'cuire et se réchauffer'
  },
  {
    question: 'Comment appelle-t-on les humains de la Préhistoire ?',
    choices: ['Les astronautes', 'Les hommes préhistoriques', 'Les chevaliers', 'Les pirates'],
    correctAnswer: 'Les hommes préhistoriques'
  },
  {
    question: 'Que chassaient parfois les hommes préhistoriques pour se nourrir ?',
    choices: ['Des mammouths', 'Des robots', 'Des tracteurs', 'Des avions'],
    correctAnswer: 'Des mammouths'
  },
  {
    question: 'Quel mot correspond à une grande pierre dressée par les hommes préhistoriques ?',
    choices: ['Menhir', 'Clavier', 'Ascenseur', 'Volcan'],
    correctAnswer: 'Menhir'
  }
];

const state = {
  currentIndex: 0,
  score: 0,
  startTime: 0,
  isLocked: false,
  answers: []
};

const dom = {
  progressFill: document.getElementById('progress-fill'),
  progressLabel: document.getElementById('progress-label'),
  questionSection: document.getElementById('question-section'),
  questionText: document.getElementById('question-text'),
  answerSection: document.getElementById('answer-section'),
  btnValidate: document.getElementById('btn-validate'),
  feedback: document.getElementById('feedback'),
  resultScreen: document.getElementById('result-screen'),
  resultEmoji: document.getElementById('result-emoji'),
  resultTitle: document.getElementById('result-title'),
  resultScore: document.getElementById('result-score'),
  resultDetail: document.getElementById('result-detail'),
  btnRestart: document.getElementById('btn-restart')
};

function init() {
  state.currentIndex = 0;
  state.score = 0;
  state.startTime = Date.now();
  state.isLocked = false;
  state.answers = [];

  dom.questionSection.style.display = 'block';
  dom.resultScreen.classList.remove('is-visible');
  _clearFeedback();
  showQuestion();
}

function showQuestion() {
  const questionActuelle = QUESTIONS[state.currentIndex];
  const numeroAffiche = state.currentIndex + 1;
  const progression = (numeroAffiche - 1) / CONFIG.totalQuestions * 100;

  dom.progressFill.style.width = progression + '%';
  dom.progressLabel.textContent = numeroAffiche + ' / ' + CONFIG.totalQuestions;
  dom.questionText.textContent = questionActuelle.question;
  dom.btnValidate.classList.add('hidden');
  _clearFeedback();
  _renderChoices(questionActuelle.choices);
}

function _renderChoices(choix) {
  dom.answerSection.innerHTML = '';

  const grille = document.createElement('div');
  grille.className = 'choices-grid';

  choix.forEach(function (choixTexte) {
    const bouton = document.createElement('button');
    bouton.type = 'button';
    bouton.className = 'choice-btn';
    bouton.textContent = choixTexte;
    bouton.addEventListener('click', function () {
      handleAnswer(choixTexte);
    });
    grille.appendChild(bouton);
  });

  dom.answerSection.appendChild(grille);
}

function _renderTextInput() {
  dom.answerSection.innerHTML = '';
}

function handleAnswer(value) {
  if (state.isLocked) {
    return;
  }

  state.isLocked = true;

  const questionActuelle = QUESTIONS[state.currentIndex];
  const reponseCorrecte = questionActuelle.correctAnswer;
  const estCorrect = value === reponseCorrecte;

  if (estCorrect) {
    state.score += 1;
    _setFeedback('Bravo ! C\'est la bonne réponse.', true);
  } else {
    _setFeedback('Ce n\'est pas la bonne réponse. La bonne réponse était : ' + reponseCorrecte, false);
  }

  state.answers.push({
    question: questionActuelle.question,
    given: String(value),
    correct: String(reponseCorrecte),
    ok: estCorrect
  });

  const boutons = dom.answerSection.querySelectorAll('.choice-btn');
  boutons.forEach(function (bouton) {
    if (bouton.textContent === reponseCorrecte) {
      _markChoiceButton(bouton, true);
    } else if (bouton.textContent === value && !estCorrect) {
      _markChoiceButton(bouton, false);
    }
    bouton.disabled = true;
  });

  _disableAnswerSection();

  window.setTimeout(function () {
    state.currentIndex += 1;
    state.isLocked = false;

    if (state.currentIndex >= CONFIG.totalQuestions) {
      showResult();
    } else {
      showQuestion();
    }
  }, CONFIG.delayNextMs);
}

function showResult() {
  const dureeMs = Date.now() - state.startTime;
  const taux = state.score / CONFIG.totalQuestions;
  const pourcentage = Math.round(taux * 100);

  dom.questionSection.style.display = 'none';
  dom.progressFill.style.width = '100%';
  dom.progressLabel.textContent = CONFIG.totalQuestions + ' / ' + CONFIG.totalQuestions;
  dom.resultScreen.classList.add('is-visible');

  if (taux >= CONFIG.passingRate) {
    dom.resultEmoji.textContent = '🎉';
    dom.resultTitle.textContent = 'Bravo, tu as réussi !';
  } else {
    dom.resultEmoji.textContent = '💪';
    dom.resultTitle.textContent = 'Continue, tu progresses !';
  }

  dom.resultScore.textContent = state.score + ' / ' + CONFIG.totalQuestions;
  dom.resultDetail.textContent = pourcentage + '% de réussite • ' + _formatDuration(dureeMs);

  const payload = {
    type: 'exercise_result',
    exerciseId: CONFIG.exerciseId,
    score: state.score,
    total: CONFIG.totalQuestions,
    successRate: taux,
    durationMs: dureeMs,
    answers: state.answers
  };

  _sendToFlutter(payload);
}

function _sendToFlutter(payload) {
  if (typeof ExerciseChannel !== 'undefined') {
    ExerciseChannel.postMessage(JSON.stringify(payload));
  } else {
    console.info('[ExerciseChannel] Hors Flutter :', payload);
  }
}

function _setFeedback(message, estCorrect) {
  dom.feedback.textContent = message;
  dom.feedback.classList.remove('feedback--empty', 'feedback--correct', 'feedback--wrong');
  dom.feedback.classList.add(estCorrect ? 'feedback--correct' : 'feedback--wrong');
}

function _clearFeedback() {
  dom.feedback.textContent = ' ';
  dom.feedback.classList.remove('feedback--correct', 'feedback--wrong');
  dom.feedback.classList.add('feedback--empty');
}

function _markChoiceButton(bouton, estCorrect) {
  bouton.classList.add(estCorrect ? 'choice-btn--correct' : 'choice-btn--wrong');
}

function _disableAnswerSection() {
  const boutons = dom.answerSection.querySelectorAll('button, input');
  boutons.forEach(function (element) {
    element.disabled = true;
  });
}

function _formatDuration(durationMs) {
  const totalSecondes = Math.max(1, Math.round(durationMs / 1000));
  const minutes = Math.floor(totalSecondes / 60);
  const secondes = totalSecondes % 60;

  if (minutes === 0) {
    return secondes + ' s';
  }

  return minutes + ' min ' + secondes + ' s';
}

dom.btnRestart.addEventListener('click', init);

document.addEventListener('DOMContentLoaded', init);
