'use strict';

const CONFIG = {
  exerciseId: 'termes_karate_ceinture_blanche_au_3e_dan',
  totalQuestions: 20,
  delayNextMs: 1400,
  passingRate: 0.6
};

const QUESTIONS = [
  {
    question: 'Que signifie « rei » au dojo ? ',
    choices: ['Salut', 'Coup de pied', 'Ceinture', 'Combat'],
    correct: 'Salut'
  },
  {
    question: 'Comment appelle-t-on le lieu d’entraînement en karaté ? ',
    choices: ['Dojo', 'Tatami', 'Kimono', 'Randori'],
    correct: 'Dojo'
  },
  {
    question: 'Quel mot désigne la tenue de pratique ? ',
    choices: ['Karategi', 'Obi', 'Sensei', 'Kata'],
    correct: 'Karategi'
  },
  {
    question: 'Comment s’appelle la ceinture en japonais ? ',
    choices: ['Obi', 'Do', 'Dan', 'Rei'],
    correct: 'Obi'
  },
  {
    question: 'Que veut dire « sensei » ? ',
    choices: ['Professeur', 'Élève', 'Arbitre', 'Champion'],
    correct: 'Professeur'
  },
  {
    question: 'Quel terme désigne une série codifiée de techniques ? ',
    choices: ['Kata', 'Kumite', 'Obi', 'Reigi'],
    correct: 'Kata'
  },
  {
    question: 'Quel mot signifie combat avec un partenaire ? ',
    choices: ['Kumite', 'Kiai', 'Dojo', 'Mokuso'],
    correct: 'Kumite'
  },
  {
    question: 'Que signifie « kiai » ? ',
    choices: ['Cri énergique', 'Salutation', 'Blocage', 'Tournoi'],
    correct: 'Cri énergique'
  },
  {
    question: 'Que veut dire « hajime » ? ',
    choices: ['Commencez', 'Arrêtez', 'Asseyez-vous', 'Merci'],
    correct: 'Commencez'
  },
  {
    question: 'Que veut dire « yame » ? ',
    choices: ['Stop', 'Plus vite', 'Salut', 'Tournez'],
    correct: 'Stop'
  },
  {
    question: 'Quel terme désigne la méditation de début ou fin de cours ? ',
    choices: ['Mokuso', 'Kumite', 'Zuki', 'Obi'],
    correct: 'Mokuso'
  },
  {
    question: 'Comment appelle-t-on une attaque de poing ? ',
    choices: ['Zuki', 'Geri', 'Uke', 'Dachi'],
    correct: 'Zuki'
  },
  {
    question: 'Comment appelle-t-on un coup de pied ? ',
    choices: ['Geri', 'Rei', 'Dan', 'Mae'],
    correct: 'Geri'
  },
  {
    question: 'Quel mot désigne une défense ou un blocage ? ',
    choices: ['Uke', 'Geri', 'Kata', 'Sensei'],
    correct: 'Uke'
  },
  {
    question: 'Que signifie « mae » dans un terme technique ? ',
    choices: ['Avant', 'Arrière', 'Côté', 'Haut'],
    correct: 'Avant'
  },
  {
    question: 'Que signifie « yoko » ? ',
    choices: ['Côté', 'Avant', 'Bas', 'Salut'],
    correct: 'Côté'
  },
  {
    question: 'Que signifie « ushiro » ? ',
    choices: ['Arrière', 'Avant', 'Rapide', 'Fort'],
    correct: 'Arrière'
  },
  {
    question: 'Quel terme désigne un grade au-dessus de la ceinture noire ? ',
    choices: ['Dan', 'Kyu', 'Obi', 'Dojo'],
    correct: 'Dan'
  },
  {
    question: 'Quel terme désigne les grades de couleur avant la ceinture noire ? ',
    choices: ['Kyu', 'Dan', 'Kata', 'Kumite'],
    correct: 'Kyu'
  },
  {
    question: 'Comment appelle-t-on la position ou posture de base ? ',
    choices: ['Dachi', 'Rei', 'Mokuso', 'Kiai'],
    correct: 'Dachi'
  },
  {
    question: 'Dans « mae geri », que veut dire l’expression complète ? ',
    choices: ['Coup de pied avant', 'Coup de poing avant', 'Blocage haut', 'Position avant'],
    correct: 'Coup de pied avant'
  },
  {
    question: 'Dans « oi zuki », quel type de technique retrouve-t-on ? ',
    choices: ['Un coup de poing', 'Un coup de pied', 'Une salutation', 'Une ceinture'],
    correct: 'Un coup de poing'
  },
  {
    question: 'Quel mot est lié au respect et à l’étiquette au dojo ? ',
    choices: ['Reigi', 'Geri', 'Dan', 'Zuki'],
    correct: 'Reigi'
  },
  {
    question: 'Que signifie « dojo kun » dans beaucoup de clubs ? ',
    choices: ['Règles ou principes du dojo', 'Tenue de combat', 'Type de kata', 'Ceinture noire'],
    correct: 'Règles ou principes du dojo'
  },
  {
    question: 'Quel terme peut désigner un pratiquant avancé, juste avant sensei dans certains contextes ? ',
    choices: ['Sempai', 'Yame', 'Uke', 'Mae'],
    correct: 'Sempai'
  },
  {
    question: 'Quel mot signifie « la voie » dans les arts martiaux ? ',
    choices: ['Do', 'Kyu', 'Obi', 'Kiai'],
    correct: 'Do'
  },
  {
    question: 'Que signifie « karate-do » dans son idée générale ? ',
    choices: ['La voie de la main vide', 'Le combat du pied rapide', 'La science des ceintures', 'Le salut du dojo'],
    correct: 'La voie de la main vide'
  },
  {
    question: 'Quel terme est le plus lié à un enchaînement seul contre des adversaires imaginaires ? ',
    choices: ['Kata', 'Kumite', 'Mokuso', 'Dojo kun'],
    correct: 'Kata'
  },
  {
    question: 'Le 1er dan correspond à quel niveau général ? ',
    choices: ['Premier grade de ceinture noire', 'Dernier grade de couleur', 'Débutant absolu', 'Niveau enfant'],
    correct: 'Premier grade de ceinture noire'
  },
  {
    question: 'Entre ceinture blanche et 3e dan, quel mot regroupe les grades noirs ? ',
    choices: ['Dan', 'Kyu', 'Obi', 'Dachi'],
    correct: 'Dan'
  },
  {
    question: 'Quel mot utilise-t-on souvent pour dire merci ou montrer le respect à la fin d’un échange au dojo ? ',
    choices: ['Osu', 'Geri', 'Yoko', 'Dachi'],
    correct: 'Osu'
  },
  {
    question: 'Si le professeur dit « mokuso », que font généralement les élèves ? ',
    choices: ['Ils se concentrent en silence', 'Ils commencent le combat', 'Ils changent de ceinture', 'Ils courent'],
    correct: 'Ils se concentrent en silence'
  },
  {
    question: 'Quel terme désigne le salut au début et à la fin de la pratique ? ',
    choices: ['Rei', 'Zuki', 'Kyu', 'Do'],
    correct: 'Rei'
  },
  {
    question: 'Dans la progression martiale, que signifie surtout apprendre les termes japonais ? ',
    choices: ['Mieux comprendre les consignes', 'Courir plus vite', 'Changer de club', 'Faire un tournoi'],
    correct: 'Mieux comprendre les consignes'
  },
  {
    question: 'Quel mot n’est PAS un grade, mais un élément de tenue ? ',
    choices: ['Obi', 'Dan', 'Kyu', '3e dan'],
    correct: 'Obi'
  }
];

const state = {
  currentIndex: 0,
  score: 0,
  startTime: 0,
  isLocked: false,
  answers: [],
  questionsSelectionnees: []
};

const dom = {
  progressFill: document.getElementById('progress-fill'),
  progressLabel: document.getElementById('progress-label'),
  progressPercent: document.getElementById('progress-percent'),
  questionSection: document.getElementById('question-section'),
  questionText: document.getElementById('question-text'),
  answerSection: document.getElementById('answer-section'),
  btnValidate: document.getElementById('btn-validate'),
  feedback: document.getElementById('feedback'),
  resultScreen: document.getElementById('result-screen'),
  resultEmoji: document.getElementById('result-emoji'),
  resultTitle: document.getElementById('result-title'),
  resultScore: document.getElementById('result-score'),
  resultDetail: document.getElementById('result-detail'),
  btnRestart: document.getElementById('btn-restart')
};

function init() {
  state.currentIndex = 0;
  state.score = 0;
  state.startTime = Date.now();
  state.isLocked = false;
  state.answers = [];
  state.questionsSelectionnees = _melangerTableau(QUESTIONS).slice(0, CONFIG.totalQuestions).map(function (question) {
    return {
      question: question.question,
      choices: _melangerTableau(question.choices),
      correct: question.correct
    };
  });

  dom.questionSection.style.display = 'block';
  dom.resultScreen.classList.remove('is-visible');
  dom.btnValidate.classList.add('hidden');
  _clearFeedback();
  showQuestion();
}

function showQuestion() {
  const questionActuelle = state.questionsSelectionnees[state.currentIndex];
  const numeroAffiche = state.currentIndex + 1;
  const pourcentage = Math.round((numeroAffiche / CONFIG.totalQuestions) * 100);

  dom.progressFill.style.width = pourcentage + '%';
  dom.progressLabel.textContent = numeroAffiche + ' / ' + CONFIG.totalQuestions;
  dom.progressPercent.textContent = pourcentage + '%';
  dom.questionText.textContent = questionActuelle.question;
  dom.answerSection.innerHTML = '';
  dom.btnValidate.classList.add('hidden');
  _clearFeedback();
  _renderChoices(questionActuelle);
}

function _renderChoices(questionObj) {
  const grille = document.createElement('div');
  grille.className = 'choices-grid';

  questionObj.choices.forEach(function (choix) {
    const bouton = document.createElement('button');
    bouton.type = 'button';
    bouton.className = 'choice-btn';
    bouton.textContent = choix;
    bouton.addEventListener('click', function () {
      handleAnswer(choix);
    });
    grille.appendChild(bouton);
  });

  dom.answerSection.appendChild(grille);
}

function _renderTextInput() {
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'text-answer';
  input.placeholder = 'Écris ta réponse';
  dom.answerSection.innerHTML = '';
  dom.answerSection.appendChild(input);
  dom.btnValidate.classList.remove('hidden');
}

function handleAnswer(value) {
  if (state.isLocked) {
    return;
  }

  state.isLocked = true;

  const questionActuelle = state.questionsSelectionnees[state.currentIndex];
  const estCorrect = value === questionActuelle.correct;

  if (estCorrect) {
    state.score += 1;
    _setFeedback('Bravo ! C’est la bonne réponse.', true);
    dom.questionSection.classList.remove('shake');
    void dom.questionSection.offsetWidth;
    dom.questionSection.classList.add('bounce');
  } else {
    _setFeedback('Oups ! La bonne réponse était : ' + questionActuelle.correct, false);
    dom.questionSection.classList.remove('bounce');
    void dom.questionSection.offsetWidth;
    dom.questionSection.classList.add('shake');
  }

  state.answers.push({
    question: questionActuelle.question,
    given: String(value),
    correct: String(questionActuelle.correct),
    ok: estCorrect
  });

  _markChoiceButton(value, questionActuelle.correct);
  _disableAnswerSection();

  window.setTimeout(function () {
    state.currentIndex += 1;
    state.isLocked = false;

    if (state.currentIndex >= CONFIG.totalQuestions) {
      showResult();
    } else {
      showQuestion();
    }
  }, CONFIG.delayNextMs);
}

function showResult() {
  const dureeMs = Date.now() - state.startTime;
  const taux = state.score / CONFIG.totalQuestions;
  const pourcentage = Math.round(taux * 100);
  const reussi = taux >= CONFIG.passingRate;

  dom.questionSection.style.display = 'none';
  dom.resultScreen.classList.add('is-visible');
  dom.resultEmoji.textContent = reussi ? '🎉' : '💪';
  dom.resultTitle.textContent = reussi ? 'Bravo, tu progresses bien !' : 'Continue, tu vas y arriver !';
  dom.resultScore.textContent = state.score + ' / ' + CONFIG.totalQuestions;
  dom.resultDetail.textContent = pourcentage + '% de réussite';

  const payload = {
    type: 'exercise_result',
    exerciseId: CONFIG.exerciseId,
    score: state.score,
    total: CONFIG.totalQuestions,
    successRate: taux,
    durationMs: dureeMs,
    answers: state.answers
  };

  _sendToFlutter(payload);
}

function _sendToFlutter(payload) {
  if (typeof ExerciseChannel !== 'undefined') {
    ExerciseChannel.postMessage(JSON.stringify(payload));
  } else {
    console.info('[ExerciseChannel] Hors Flutter :', payload);
  }
}

function _setFeedback(message, estCorrect) {
  dom.feedback.textContent = message;
  dom.feedback.classList.remove('feedback--empty', 'feedback--correct', 'feedback--wrong');
  dom.feedback.classList.add(estCorrect ? 'feedback--correct' : 'feedback--wrong');
}

function _clearFeedback() {
  dom.feedback.textContent = ' '; 
  dom.feedback.classList.remove('feedback--correct', 'feedback--wrong');
  dom.feedback.classList.add('feedback--empty');
}

function _markChoiceButton(reponseChoisie, bonneReponse) {
  const boutons = dom.answerSection.querySelectorAll('.choice-btn');
  boutons.forEach(function (bouton) {
    const texte = bouton.textContent;
    if (texte === bonneReponse) {
      bouton.classList.add('choice-btn--correct');
    }
    if (texte === reponseChoisie && texte !== bonneReponse) {
      bouton.classList.add('choice-btn--wrong');
    }
  });
}

function _disableAnswerSection() {
  const elements = dom.answerSection.querySelectorAll('button, input');
  elements.forEach(function (element) {
    element.disabled = true;
  });
}

function _melangerTableau(tableau) {
  const copie = tableau.slice();
  for (let i = copie.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const temp = copie[i];
    copie[i] = copie[j];
    copie[j] = temp;
  }
  return copie;
}

document.addEventListener('DOMContentLoaded', function () {
  dom.btnRestart.addEventListener('click', init);
  init();
});