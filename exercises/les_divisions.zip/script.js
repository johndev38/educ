'use strict';

const CONFIG = {
  exerciseId: 'divisions_simples',
  totalQuestions: 8,
  delayNextMs: 1400,
  passingRate: 0.6
};

const QUESTIONS = [
  {
    question: '12 ÷ 3 = ?',
    choices: ['4', '3', '6', '5'],
    correct: '4'
  },
  {
    question: '15 ÷ 5 = ?',
    choices: ['2', '3', '5', '4'],
    correct: '3'
  },
  {
    question: '18 ÷ 2 = ?',
    choices: ['8', '7', '9', '6'],
    correct: '9'
  },
  {
    question: '20 ÷ 4 = ?',
    choices: ['6', '4', '5', '3'],
    correct: '5'
  },
  {
    question: '24 ÷ 6 = ?',
    choices: ['4', '6', '3', '5'],
    correct: '4'
  },
  {
    question: '21 ÷ 7 = ?',
    choices: ['2', '3', '4', '5'],
    correct: '3'
  },
  {
    question: '16 ÷ 8 = ?',
    choices: ['4', '1', '2', '3'],
    correct: '2'
  },
  {
    question: '27 ÷ 9 = ?',
    choices: ['2', '4', '6', '3'],
    correct: '3'
  }
];

const state = {
  currentIndex: 0,
  score: 0,
  startTime: 0,
  isLocked: false,
  answers: []
};

const dom = {
  progressFill: document.getElementById('progress-fill'),
  progressLabel: document.getElementById('progress-label'),
  questionSection: document.getElementById('question-section'),
  questionText: document.getElementById('question-text'),
  answerSection: document.getElementById('answer-section'),
  btnValidate: document.getElementById('btn-validate'),
  feedback: document.getElementById('feedback'),
  resultScreen: document.getElementById('result-screen'),
  resultEmoji: document.getElementById('result-emoji'),
  resultTitle: document.getElementById('result-title'),
  resultScore: document.getElementById('result-score'),
  resultDetail: document.getElementById('result-detail'),
  btnRestart: document.getElementById('btn-restart')
};

function init() {
  state.currentIndex = 0;
  state.score = 0;
  state.startTime = Date.now();
  state.isLocked = false;
  state.answers = [];

  dom.questionSection.classList.remove('is-hidden');
  dom.resultScreen.classList.remove('is-visible');
  dom.btnValidate.hidden = true;
  _clearFeedback();
  showQuestion();
}

function showQuestion() {
  const questionActuelle = QUESTIONS[state.currentIndex];
  const progression = ((state.currentIndex) / CONFIG.totalQuestions) * 100;

  dom.progressFill.style.width = progression + '%';
  dom.progressLabel.textContent = (state.currentIndex + 1) + ' / ' + CONFIG.totalQuestions;
  dom.questionText.textContent = questionActuelle.question;
  _clearFeedback();
  _renderChoices(questionActuelle);
}

function _renderChoices(questionObj) {
  dom.answerSection.innerHTML = '';
  const grille = document.createElement('div');
  grille.className = 'choices-grid';

  questionObj.choices.forEach(function (choix) {
    const bouton = document.createElement('button');
    bouton.className = 'choice-btn';
    bouton.type = 'button';
    bouton.textContent = choix;
    bouton.addEventListener('click', function () {
      handleAnswer(choix);
    });
    grille.appendChild(bouton);
  });

  dom.answerSection.appendChild(grille);
}

function _renderTextInput() {
  dom.answerSection.innerHTML = '';
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'saisie-reponse';
  input.placeholder = 'Écris ta réponse';
  dom.answerSection.appendChild(input);
  dom.btnValidate.hidden = false;
}

function handleAnswer(value) {
  if (state.isLocked) {
    return;
  }

  state.isLocked = true;

  const questionActuelle = QUESTIONS[state.currentIndex];
  const bonneReponse = questionActuelle.correct;
  const estCorrect = String(value).trim() === String(bonneReponse).trim();

  if (estCorrect) {
    state.score += 1;
    _setFeedback('Bravo ! C\'est la bonne réponse.', true);
  } else {
    _setFeedback('Oups ! La bonne réponse était ' + bonneReponse + '.', false);
  }

  state.answers.push({
    question: questionActuelle.question,
    given: String(value),
    correct: String(bonneReponse),
    ok: estCorrect
  });

  _markChoiceButton(value, bonneReponse);
  _disableAnswerSection();

  window.setTimeout(function () {
    state.currentIndex += 1;
    state.isLocked = false;

    if (state.currentIndex >= CONFIG.totalQuestions) {
      showResult();
      return;
    }

    showQuestion();
  }, CONFIG.delayNextMs);
}

function showResult() {
  const dureeMs = Date.now() - state.startTime;
  const taux = state.score / CONFIG.totalQuestions;
  const pourcentage = Math.round(taux * 100);
  const reussi = taux >= CONFIG.passingRate;

  dom.questionSection.classList.add('is-hidden');
  dom.resultScreen.classList.add('is-visible');
  dom.progressFill.style.width = '100%';
  dom.progressLabel.textContent = CONFIG.totalQuestions + ' / ' + CONFIG.totalQuestions;

  dom.resultEmoji.textContent = reussi ? '🎉' : '💪';
  dom.resultTitle.textContent = reussi ? 'Bravo, tu as réussi !' : 'Continue, tu progresses !';
  dom.resultScore.textContent = state.score + ' / ' + CONFIG.totalQuestions;
  dom.resultDetail.textContent = pourcentage + '% de réussite · ' + _formatDuration(dureeMs);

  const payload = {
    type: 'exercise_result',
    exerciseId: CONFIG.exerciseId,
    score: state.score,
    total: CONFIG.totalQuestions,
    successRate: taux,
    durationMs: dureeMs,
    answers: state.answers.map(function (reponse) {
      return {
        question: reponse.question,
        given: reponse.given,
        correct: reponse.correct,
        ok: reponse.ok
      };
    })
  };

  _sendToFlutter(payload);
}

function _sendToFlutter(payload) {
  if (typeof ExerciseChannel !== 'undefined') {
    ExerciseChannel.postMessage(JSON.stringify(payload));
  } else {
    console.info('[ExerciseChannel] Hors Flutter :', payload);
  }
}

function _setFeedback(message, estCorrect) {
  dom.feedback.textContent = message;
  dom.feedback.classList.remove('feedback--empty', 'feedback--correct', 'feedback--wrong');
  dom.feedback.classList.add(estCorrect ? 'feedback--correct' : 'feedback--wrong');
}

function _clearFeedback() {
  dom.feedback.textContent = '.';
  dom.feedback.classList.remove('feedback--correct', 'feedback--wrong');
  dom.feedback.classList.add('feedback--empty');
}

function _markChoiceButton(reponseChoisie, bonneReponse) {
  const boutons = dom.answerSection.querySelectorAll('.choice-btn');

  boutons.forEach(function (bouton) {
    const valeur = bouton.textContent;

    if (valeur === bonneReponse) {
      bouton.classList.add('choice-btn--correct');
    }

    if (valeur === reponseChoisie && reponseChoisie !== bonneReponse) {
      bouton.classList.add('choice-btn--wrong');
    }
  });
}

function _disableAnswerSection() {
  const boutons = dom.answerSection.querySelectorAll('button, input');
  boutons.forEach(function (element) {
    element.disabled = true;
  });
}

function _formatDuration(durationMs) {
  const totalSecondes = Math.max(1, Math.round(durationMs / 1000));
  const minutes = Math.floor(totalSecondes / 60);
  const secondes = totalSecondes % 60;

  if (minutes === 0) {
    return secondes + ' s';
  }

  return minutes + ' min ' + String(secondes).padStart(2, '0') + ' s';
}

dom.btnRestart.addEventListener('click', init);

document.addEventListener('DOMContentLoaded', init);