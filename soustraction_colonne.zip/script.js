let questionElement = document.getElementById("question");
let choicesElement = document.getElementById("choices");
let timerElement = document.getElementById("timer");
let scoreElement = document.getElementById("score");

let currentAnswer = 0;
let score = 0;
let timeLeft = 12;
let timer = null;

function generateQuestion() {

    // Génère deux nombres (avec possibilité de retenue)
    let a = Math.floor(Math.random() * 900) + 100;
    let b = Math.floor(Math.random() * 900) + 100;

    if (b > a) {
        let tmp = a;
        a = b;
        b = tmp;
    }

    currentAnswer = a - b;

    questionElement.innerHTML = `
        <div class="column">
            <div class="line">${a}</div>
            <div class="line">- ${b}</div>
            <div class="separator"></div>
            <div class="result">?</div>
        </div>
    `;

    generateChoices();
}

function generateChoices() {

    choicesElement.innerHTML = "";

    let answers = [currentAnswer];

    while (answers.length < 4) {

        let fake = currentAnswer + Math.floor(Math.random() * 20) - 10;

        if (fake >= 0 && !answers.includes(fake)) {
            answers.push(fake);
        }
    }

    shuffleArray(answers);

    answers.forEach(value => {

        let btn = document.createElement("button");
        btn.className = "choice";
        btn.innerText = value;

        btn.onclick = () => checkAnswer(value);

        choicesElement.appendChild(btn);
    });
}

function checkAnswer(value) {

    if (value === currentAnswer) {

        score++;

        if (score >= 15) {
            finishExercise(true);
            return;
        }

        scoreElement.innerText = "Score : " + score;
        generateQuestion();

    } else {
        finishExercise(false);
    }
}

function startTimer() {

    timeLeft = 12;
    timerElement.innerText = timeLeft;

    if (timer) clearInterval(timer);

    timer = setInterval(() => {

        timeLeft--;
        timerElement.innerText = timeLeft;

        if (timeLeft <= 0) {
            clearInterval(timer);
            finishExercise(false);
        }

    }, 1000);
}

function finishExercise(success) {

    clearInterval(timer);

    if (window.ExerciseChannel) {
        ExerciseChannel.postMessage(JSON.stringify({
            success: success,
            score: score
        }));
    }

    alert(success ? "Bravo !" : "Perdu !");
    location.reload();
}

function shuffleArray(array) {

    for (let i = array.length - 1; i > 0; i--) {

        let j = Math.floor(Math.random() * (i + 1));

        let temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

function init() {

    score = 0;
    scoreElement.innerText = "Score : 0";

    generateQuestion();
    startTimer();
}

window.onload = init;